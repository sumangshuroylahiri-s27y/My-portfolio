# Sumansu Roy — Portfolio Website

A modern, production-ready static portfolio website for freelancer **Sumansu Roy**, built with HTML5, CSS3, and Vanilla JavaScript. Deployable on **GitHub Pages** and **Netlify** with zero configuration.

---

## 📁 Project Structure

```
portfolio-website/
├── index.html      ← Main HTML file (entry point)
├── style.css       ← All styles (design system, layout, animations)
├── script.js       ← All JavaScript (interactions, form, cursor, etc.)
├── images/         ← Put your photos here (see instructions below)
└── README.md       ← This file
```

---

## 🖼️ Adding Your Photo

1. Copy your profile photo into the `images/` folder and name it `profile.jpg`
2. Open `index.html` and find the two `<img>` tags with `placehold.co` URLs
3. Replace them with:
   ```html
   <img src="images/profile.jpg" alt="Sumansu Roy" />
   ```

---

## 📧 Setting Up EmailJS (Contact Form)

The contact form uses **EmailJS** — a free service that sends emails without any backend server.

### Step 1 — Create a free EmailJS account
Go to [https://www.emailjs.com](https://www.emailjs.com) and sign up for free.

### Step 2 — Create an Email Service
- Dashboard → **Email Services** → **Add New Service**
- Choose Gmail (or any provider) and connect your email
- Copy the **Service ID** (e.g. `service_abc123`)

### Step 3 — Create an Email Template
- Dashboard → **Email Templates** → **Create New Template**
- Use these variables in your template:
  ```
  From: {{from_name}} <{{from_email}}>
  Subject: New enquiry — {{service}}
  
  Name:    {{from_name}}
  Email:   {{from_email}}
  Phone:   {{phone}}
  Service: {{service}}
  
  Message:
  {{message}}
  ```
- Copy the **Template ID** (e.g. `template_xyz789`)

### Step 4 — Get your Public Key
- Dashboard → **Account** → **API Keys** → copy **Public Key**

### Step 5 — Update script.js
Open `script.js` and replace the three placeholder values (around line 115):

```javascript
const EMAILJS_PUBLIC_KEY  = 'YOUR_PUBLIC_KEY';    // ← replace with your Public Key
const EMAILJS_SERVICE_ID  = 'YOUR_SERVICE_ID';    // ← replace with your Service ID
const EMAILJS_TEMPLATE_ID = 'YOUR_TEMPLATE_ID';   // ← replace with your Template ID
```

> **Note:** Until you add your keys, the form will run in demo mode — it simulates success without sending an email. This is safe for testing.

---

## 🔗 Updating Social Media Links

Open `index.html` and search for the social icon links. Replace the `href` values:

```html
<a href="https://linkedin.com/in/YOUR-PROFILE"  ...>LinkedIn</a>
<a href="https://facebook.com/YOUR-PROFILE"      ...>Facebook</a>
<a href="https://instagram.com/YOUR-HANDLE"      ...>Instagram</a>
```

---

## 🚀 Deploying to GitHub

### Option A — GitHub Desktop (easiest)
1. Download and install [GitHub Desktop](https://desktop.github.com/)
2. Click **File → Add Local Repository** → select the `portfolio-website` folder
3. Click **Publish Repository** → name it `portfolio-website` → publish

### Option B — Command Line

```bash
# 1. Navigate into the project folder
cd portfolio-website

# 2. Initialise a Git repository
git init

# 3. Add all files
git add .

# 4. Make your first commit
git commit -m "Initial commit — portfolio website"

# 5. Go to github.com and create a new repository named: portfolio-website
#    (do NOT initialise it with README)

# 6. Link and push
git remote add origin https://github.com/YOUR-USERNAME/portfolio-website.git
git branch -M main
git push -u origin main
```

---

## 🌐 Deploying to Netlify (Free Hosting)

### Method 1 — Drag and Drop (fastest, no account needed)
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag and drop the entire `portfolio-website` folder onto the page
3. Your site is live instantly! You'll get a URL like `https://random-name.netlify.app`

### Method 2 — Connect GitHub (recommended — auto-deploys on every update)
1. Go to [https://app.netlify.com](https://app.netlify.com) and sign up with GitHub
2. Click **Add new site → Import an existing project**
3. Choose **GitHub** → select `portfolio-website` repository
4. Settings:
   - **Branch to deploy:** `main`
   - **Build command:** *(leave empty)*
   - **Publish directory:** `.` (just a dot — the root folder)
5. Click **Deploy site**
6. Done! Every `git push` will automatically redeploy.

### Custom Domain on Netlify
1. Site settings → **Domain management** → **Add custom domain**
2. Enter your domain (e.g. `sumanshuroy.in`)
3. Follow the DNS instructions provided by Netlify

---

## ✏️ Customisation Guide

| What to change | Where |
|---|---|
| Name / tagline | `index.html` — Hero section |
| Services | `index.html` — Services section |
| Portfolio images | Replace placeholder `<img>` tags in Portfolio section |
| Testimonials | `index.html` — Testimonials section |
| Phone / Email | `index.html` — search `9800287516` and `sumangshuroylahiri` |
| Social links | `index.html` — Social strip and footer |
| Colours | `style.css` — `:root` CSS variables at top of file |
| Fonts | `index.html` — Google Fonts `<link>` tag |

---

## 🛠️ Tech Stack

| Tool | Purpose |
|---|---|
| HTML5 | Structure |
| CSS3 | Styling, animations, responsive layout |
| Vanilla JavaScript | Interactions, scroll effects, form validation |
| EmailJS (CDN) | Contact form email delivery |
| Remix Icons (CDN) | Icon library |
| Google Fonts (CDN) | Typography |

> No Node.js, no npm, no build step. Open `index.html` directly in your browser to preview.

---

## 📄 License

© 2026 Sumansu Roy. All rights reserved.
