/* ============================================================
   SUMANSU ROY PORTFOLIO — script.js
   Vanilla JS | No dependencies (except EmailJS via CDN)
   ============================================================ */

'use strict';

/* ── 1. CUSTOM CURSOR ──────────────────────────────────────── */
(function initCursor() {
  const dot  = document.getElementById('cursor');
  const ring = document.getElementById('cursorRing');
  if (!dot || !ring) return;

  let mouseX = 0, mouseY = 0;
  let ringX  = 0, ringY  = 0;

  document.addEventListener('mousemove', e => {
    mouseX = e.clientX; mouseY = e.clientY;
    dot.style.left = mouseX + 'px';
    dot.style.top  = mouseY + 'px';
  });

  // Slightly lagged ring
  (function animateRing() {
    ringX += (mouseX - ringX) * 0.14;
    ringY += (mouseY - ringY) * 0.14;
    ring.style.left = ringX + 'px';
    ring.style.top  = ringY + 'px';
    requestAnimationFrame(animateRing);
  })();

  // Hover scale
  document.querySelectorAll('a, button, .service-card, .portfolio-item, .filter-btn').forEach(el => {
    el.addEventListener('mouseenter', () => { dot.classList.add('hover'); ring.classList.add('hover'); });
    el.addEventListener('mouseleave', () => { dot.classList.remove('hover'); ring.classList.remove('hover'); });
  });
})();

/* ── 2. NAVBAR SCROLL BEHAVIOUR ────────────────────────────── */
(function initNavbar() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;

  function onScroll() {
    if (window.scrollY > 60) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
    updateActiveLink();
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* ── 3. ACTIVE NAV LINK ─────────────────────────────────────── */
function updateActiveLink() {
  const sections = document.querySelectorAll('section[id]');
  const links    = document.querySelectorAll('.nav-links a, .mobile-menu a');
  const offset   = 120;

  let current = '';
  sections.forEach(sec => {
    if (window.scrollY >= sec.offsetTop - offset) {
      current = sec.getAttribute('id');
    }
  });

  links.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === '#' + current) {
      link.classList.add('active');
    }
  });
}

/* ── 4. HAMBURGER MENU ──────────────────────────────────────── */
(function initMobileMenu() {
  const btn    = document.getElementById('hamburgerBtn');
  const menu   = document.getElementById('mobileMenu');
  const links  = menu ? menu.querySelectorAll('a') : [];
  if (!btn || !menu) return;

  btn.addEventListener('click', () => {
    btn.classList.toggle('open');
    menu.classList.toggle('open');
    document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
  });

  links.forEach(link => {
    link.addEventListener('click', () => {
      btn.classList.remove('open');
      menu.classList.remove('open');
      document.body.style.overflow = '';
    });
  });
})();

/* ── 5. SMOOTH SCROLL ───────────────────────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = 80;
      window.scrollTo({
        top: target.offsetTop - offset,
        behavior: 'smooth'
      });
    }
  });
});

/* ── 6. SCROLL REVEAL ───────────────────────────────────────── */
(function initReveal() {
  const els = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');
  if (!els.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, idx) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, idx * 60);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  els.forEach(el => observer.observe(el));
})();

/* ── 7. PORTFOLIO FILTER ────────────────────────────────────── */
(function initPortfolioFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const items      = document.querySelectorAll('.portfolio-item');
  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      filterBtns.forEach(b => b.classList.remove('active'));
      this.classList.add('active');

      const filter = this.dataset.filter;

      items.forEach(item => {
        if (filter === 'all' || item.dataset.category === filter) {
          item.classList.remove('hidden');
        } else {
          item.classList.add('hidden');
        }
      });
    });
  });
})();

/* ── 8. BACK TO TOP ─────────────────────────────────────────── */
(function initBackToTop() {
  const btn = document.getElementById('back-to-top');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      btn.classList.add('visible');
    } else {
      btn.classList.remove('visible');
    }
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();

/* ── 9. TOAST HELPER ────────────────────────────────────────── */
function showToast(message, duration = 3500) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), duration);
}

/* ── 10. CONTACT FORM VALIDATION ────────────────────────────── */
(function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  const successBox  = document.getElementById('formSuccess');
  const submitBtn   = form.querySelector('.form-submit');
  const btnText     = document.getElementById('btnText');
  const btnSpinner  = document.getElementById('btnSpinner');

  function validateField(group, value, type = 'text') {
    const msgEl = group.querySelector('.error-msg');
    group.classList.remove('error');

    if (!value.trim()) {
      group.classList.add('error');
      if (msgEl) msgEl.textContent = 'This field is required.';
      return false;
    }
    if (type === 'email') {
      const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRe.test(value)) {
        group.classList.add('error');
        if (msgEl) msgEl.textContent = 'Please enter a valid email address.';
        return false;
      }
    }
    if (type === 'phone') {
      const phoneRe = /^[+\d\s\-()]{7,15}$/;
      if (!phoneRe.test(value)) {
        group.classList.add('error');
        if (msgEl) msgEl.textContent = 'Please enter a valid phone number.';
        return false;
      }
    }
    return true;
  }

  // Live validation on blur
  form.querySelectorAll('input, select, textarea').forEach(field => {
    field.addEventListener('blur', () => {
      const group = field.closest('.form-group');
      const type  = field.type === 'email' ? 'email' :
                    field.id   === 'phone'  ? 'phone' : 'text';
      validateField(group, field.value, type);
    });
    // Clear error on input
    field.addEventListener('input', () => {
      field.closest('.form-group').classList.remove('error');
    });
  });

  form.addEventListener('submit', async function(e) {
    e.preventDefault();

    const nameGroup    = document.getElementById('name').closest('.form-group');
    const emailGroup   = document.getElementById('email').closest('.form-group');
    const phoneGroup   = document.getElementById('phone').closest('.form-group');
    const serviceGroup = document.getElementById('service').closest('.form-group');
    const msgGroup     = document.getElementById('message').closest('.form-group');

    const v1 = validateField(nameGroup,    document.getElementById('name').value);
    const v2 = validateField(emailGroup,   document.getElementById('email').value,   'email');
    const v3 = validateField(phoneGroup,   document.getElementById('phone').value,   'phone');
    const v4 = validateField(serviceGroup, document.getElementById('service').value);
    const v5 = validateField(msgGroup,     document.getElementById('message').value);

    if (!(v1 && v2 && v3 && v4 && v5)) {
      showToast('⚠ Please fix the errors above.');
      return;
    }

    // Show loading state
    submitBtn.disabled = true;
    if (btnText)    btnText.textContent  = 'Sending…';
    if (btnSpinner) btnSpinner.style.display = 'inline-block';

    /* ─── EmailJS Integration ────────────────────────────────
       Replace with your own EmailJS credentials:
         - YOUR_PUBLIC_KEY   → EmailJS account → API Keys
         - YOUR_SERVICE_ID   → EmailJS dashboard → Email Services
         - YOUR_TEMPLATE_ID  → EmailJS dashboard → Email Templates
       Template variables used: {{from_name}}, {{from_email}},
       {{phone}}, {{service}}, {{message}}
    ─────────────────────────────────────────────────────────── */
    const EMAILJS_PUBLIC_KEY  = 'YOUR_PUBLIC_KEY';    // ← replace
    const EMAILJS_SERVICE_ID  = 'YOUR_SERVICE_ID';    // ← replace
    const EMAILJS_TEMPLATE_ID = 'YOUR_TEMPLATE_ID';   // ← replace

    const templateParams = {
      from_name  : document.getElementById('name').value.trim(),
      from_email : document.getElementById('email').value.trim(),
      phone      : document.getElementById('phone').value.trim(),
      service    : document.getElementById('service').value,
      message    : document.getElementById('message').value.trim(),
      reply_to   : document.getElementById('email').value.trim(),
    };

    try {
      if (typeof emailjs !== 'undefined' && EMAILJS_PUBLIC_KEY !== 'YOUR_PUBLIC_KEY') {
        emailjs.init(EMAILJS_PUBLIC_KEY);
        await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, templateParams);
      } else {
        // Demo mode: simulate success when EmailJS not configured
        await new Promise(r => setTimeout(r, 1200));
        console.info('[Demo] EmailJS not configured. Message data:', templateParams);
      }

      // Success UI
      form.style.display      = 'none';
      successBox.classList.add('visible');
      showToast('✓ Message sent successfully!');

    } catch (err) {
      console.error('EmailJS error:', err);
      showToast('✕ Something went wrong. Please try again or email directly.');
      submitBtn.disabled = false;
      if (btnText)    btnText.textContent  = 'Send Message';
      if (btnSpinner) btnSpinner.style.display = 'none';
    }
  });
})();

/* ── 11. ANIMATED COUNTER (stats in hero) ───────────────────── */
(function initCounters() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el  = entry.target;
      const end = parseInt(el.dataset.count);
      const dur = 1600;
      const step = 30;
      const inc  = Math.ceil(end / (dur / step));
      let cur    = 0;
      const timer = setInterval(() => {
        cur += inc;
        if (cur >= end) { cur = end; clearInterval(timer); }
        el.textContent = cur + (el.dataset.suffix || '');
      }, step);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));
})();

/* ── 12. YEAR IN FOOTER ─────────────────────────────────────── */
document.querySelectorAll('.current-year').forEach(el => {
  el.textContent = new Date().getFullYear();
});
