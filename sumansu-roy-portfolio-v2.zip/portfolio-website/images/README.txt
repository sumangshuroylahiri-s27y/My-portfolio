IMAGES FOLDER
=============
Place your photos here:

  profile.jpg   → Your main profile/headshot photo
                  Recommended: 420x480px or larger, portrait orientation

Then in index.html, replace the placeholder image tags:
  src="https://placehold.co/..." 
with:
  src="images/profile.jpg"
